#!/usr/bin/env bash
# Install self-contained KiCad documentation + Git backup automation into a project.
# Usage: ./install.sh /path/to/project [--project NAME] [--minutes N] [--replace-legacy]
set -Eeuo pipefail
export PATH="$HOME/.local/bin:$PATH"
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET=''
NAME=''
MINUTES=15
REPLACE_LEGACY=0
while (($#)); do
  case "$1" in
    --project) NAME="${2:?Missing project name}"; shift 2 ;;
    --minutes) MINUTES="${2:?Missing minutes}"; shift 2 ;;
    --replace-legacy) REPLACE_LEGACY=1; shift ;;
    --help|-h) sed -n '2,3p' "$0"; exit 0 ;;
    -*) echo "Unknown option: $1" >&2; exit 2 ;;
    *) [[ -z "$TARGET" ]] || { echo 'Only one project directory allowed' >&2; exit 2; }; TARGET="$1"; shift ;;
  esac
done
[[ -n "$TARGET" ]] || { echo 'Specify KiCad project directory' >&2; exit 2; }
[[ "$MINUTES" =~ ^[0-9]+$ ]] && ((MINUTES >= 1 && MINUTES <= 1440)) || { echo 'Minutes must be 1..1440' >&2; exit 2; }
TARGET="$(realpath -e "$TARGET")"
[[ -d "$TARGET" ]] || exit 1
if [[ -z "$NAME" ]]; then
  mapfile -d '' -t projects < <(find "$TARGET" -maxdepth 1 -type f -name '*.kicad_pro' -print0)
  if ((${#projects[@]} != 1)); then
    printf 'Expected exactly one .kicad_pro in project root, found %s; use --project NAME\n' "${#projects[@]}" >&2
    exit 1
  fi
  NAME="$(basename "${projects[0]}" .kicad_pro)"
fi
[[ "$NAME" != */* && "$NAME" != *$'\n'* && -f "$TARGET/$NAME.kicad_pro" && -f "$TARGET/$NAME.kicad_sch" && -f "$TARGET/$NAME.kicad_pcb" ]] || { echo 'Matching .kicad_pro/.kicad_sch/.kicad_pcb not found' >&2; exit 1; }
command -v git >/dev/null && git -C "$TARGET" rev-parse --show-toplevel >/dev/null || { echo 'Initialize a Git repository first (git init), and configure origin.' >&2; exit 1; }
[[ "$(git -C "$TARGET" rev-parse --show-toplevel)" == "$TARGET" ]] || { echo 'Install only in Git repository root' >&2; exit 1; }
BRANCH="$(git -C "$TARGET" branch --show-current)"
[[ -n "$BRANCH" ]] || { echo 'Checkout a named branch first' >&2; exit 1; }
command -v systemctl >/dev/null || { echo 'systemd is required' >&2; exit 1; }
for cmd in kicad-cli pdfinfo pdftoppm python3 flock sha256sum; do
  command -v "$cmd" >/dev/null || { echo "Missing $cmd; install dependencies and ensure it is on PATH" >&2; exit 1; }
done
python3 -c 'from PIL import Image' || { echo 'Missing Pillow: sudo apt install python3-pil' >&2; exit 1; }
if ! git -C "$TARGET" remote get-url origin >/dev/null 2>&1; then
  echo 'WARNING: Git origin not configured. Export/commit can work; push will fail until origin is set.' >&2
fi
HASH="$(printf '%s' "$TARGET" | sha256sum | cut -c1-12)"
UNIT="kicad-auto-${HASH}"
USER_UNITS="$HOME/.config/systemd/user"
mkdir -p "$TARGET/scripts" "$USER_UNITS"
if (( REPLACE_LEGACY )); then
  systemctl --user disable --now kicad-git.timer 2>/dev/null || true
  echo 'Legacy kicad-git.timer disabled'
elif systemctl --user is-active --quiet kicad-git.timer 2>/dev/null; then
  echo 'WARNING: legacy kicad-git.timer is running; use --replace-legacy to avoid duplicate jobs.' >&2
  exit 1
fi
# Never overwrite the user's existing automation scripts without keeping recoverable backups.
for file in auto-git.sh export-pdf.sh generate-readme.py check-docs.py; do
  if [[ -e "$TARGET/scripts/$file" ]] && ! cmp -s "$PKG/scripts/$file" "$TARGET/scripts/$file"; then
    cp -p "$TARGET/scripts/$file" "$TARGET/scripts/$file.pre-kicad-auto.bak"
  fi
  cp "$PKG/scripts/$file" "$TARGET/scripts/$file"
done
chmod +x "$TARGET/scripts/auto-git.sh" "$TARGET/scripts/export-pdf.sh"
if [[ -f "$TARGET/.kicad-automation.conf" ]]; then
  cp -p "$TARGET/.kicad-automation.conf" "$TARGET/.kicad-automation.conf.pre-kicad-auto.bak"
fi
printf 'PROJECT_NAME=%q\nGIT_BRANCH=%q\n' "$NAME" "$BRANCH" > "$TARGET/.kicad-automation.conf"
# Quote unit path to support spaces; % must be doubled in systemd unit strings.
SYSTEMD_PATH="${TARGET//%/%%}/scripts/auto-git.sh"
SYSTEMD_PATH="${SYSTEMD_PATH//\\/\\\\}"
SYSTEMD_PATH="${SYSTEMD_PATH//\"/\\\"}"
cat > "$USER_UNITS/$UNIT.service" <<SERVICE
[Unit]
Description=KiCad automation for $NAME

[Service]
Type=oneshot
Environment="PATH=%h/.local/bin:/usr/local/bin:/usr/bin:/bin"
ExecStart=/usr/bin/bash "$SYSTEMD_PATH"
TimeoutStartSec=10min
SERVICE
cat > "$USER_UNITS/$UNIT.timer" <<TIMER
[Unit]
Description=KiCad automation every $MINUTES minutes ($NAME)

[Timer]
OnStartupSec=2min
OnUnitInactiveSec=${MINUTES}min
AccuracySec=1min
Unit=$UNIT.service

[Install]
WantedBy=timers.target
TIMER
systemctl --user daemon-reload
systemctl --user enable --now "$UNIT.timer"
printf '\nInstalled %s for %s (branch: %s)\n' "$UNIT" "$TARGET" "$BRANCH"
printf 'Test: systemctl --user start %s.service\n' "$UNIT"
printf 'Logs: journalctl --user -u %s.service -n 60 --no-pager\n' "$UNIT"
printf 'Timer: systemctl --user list-timers --all | grep %s\n' "$UNIT"
printf 'Project config: %s/.kicad-automation.conf\n' "$TARGET"
