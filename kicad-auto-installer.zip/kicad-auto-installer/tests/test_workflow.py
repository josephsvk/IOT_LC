#!/usr/bin/env python3
"""End-to-end smoke test using a fake KiCad CLI and real git/PDF/PNG tools."""
import os
from pathlib import Path
import subprocess
import tempfile

PACKAGE = Path(__file__).resolve().parent.parent

def run(*args, cwd=None, env=None):
    res = subprocess.run(args, cwd=cwd, env=env, text=True, capture_output=True)
    if res.returncode:
        print("FAILED:", args, "STDOUT:", res.stdout, "STDERR:", res.stderr)
        res.check_returncode()
    return res

def main():
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        repo = base / 'project'
        repo.mkdir()
        bare = base / 'remote.git'
        run('git', 'init', '--bare', str(bare))
        run('git', 'init', '-b', 'main', cwd=repo)
        run('git', 'config', 'user.email', 'test@example.com', cwd=repo)
        run('git', 'config', 'user.name', 'Test', cwd=repo)
        (repo / 'TestBoard.kicad_pro').write_text('{}')
        (repo / 'TestBoard.kicad_sch').write_text('active')
        (repo / 'TestBoard.kicad_pcb').write_text('board')
        (repo / 'DraftUnused.kicad_sch').write_text('unused draft')
        run('bash', str(PACKAGE / 'bootstrap.sh'), str(repo), '--remote', str(bare))
        fake = base / 'bin'
        fake.mkdir()
        cli = fake / 'kicad-cli'
        cli.write_text('''#!/usr/bin/env python3
import sys
from reportlab.pdfgen import canvas
from pathlib import Path
args = sys.argv[1:]
if 'version' in args: print('10.0.8'); sys.exit(0)
out = Path(args[args.index('-o') + 1])
c = canvas.Canvas(str(out), pagesize=(500, 500))
count = 3 if args[0:3] == ['sch','export','pdf'] else (4 if '--mode-multipage' in args else 1)
for i in range(count):
    c.setFont('Helvetica', 16)
    c.drawString(80, 350, f'Page {i+1}: active content')
    c.rect(60, 60, 380, 380)
    c.showPage()
c.save()
''')
        cli.chmod(0o755)
        env = dict(os.environ, PATH=f'{fake}:{os.environ["PATH"]}')
        for name in ('auto-git.sh', 'export-pdf.sh', 'check-docs.py', 'generate-readme.py'):
            (repo / 'scripts').mkdir(exist_ok=True)
            (repo / 'scripts' / name).write_bytes((PACKAGE / 'scripts' / name).read_bytes())
        (repo / '.kicad-automation.conf').write_text('PROJECT_NAME=TestBoard\nGIT_BRANCH=main\n')
        run('git', 'add', '-A', cwd=repo)
        run('git', 'commit', '-m', 'initial', cwd=repo)
        run('git', 'push', '-u', 'origin', 'main', cwd=repo)
        first = run('bash', 'scripts/auto-git.sh', cwd=repo, env=env)
        assert 'Documentation validation passed' in first.stdout, first.stdout
        readme = (repo / 'README.md').read_text()
        assert readme.count('![Complete active hierarchical schematic') == 3
        assert 'DraftUnused' not in readme
        assert (repo / 'docs/images/pcb-layers-004.png').exists()
        run('git', 'status', '--porcelain', cwd=repo)
        next_run = run('bash', 'scripts/auto-git.sh', cwd=repo, env=env)
        assert 'Documentation unchanged; skipping export' not in next_run.stdout or 'Documentation validation passed' in next_run.stdout
        assert 'Documentation validation passed' in next_run.stdout
        (repo / 'TestBoard.kicad_pcb').write_text('board changed')
        new_run = run('bash', 'scripts/auto-git.sh', cwd=repo, env=env)
        assert 'Input changed; exporting' in new_run.stdout
        status = run('git', 'status', '--porcelain', cwd=repo).stdout.strip()
        assert not status, status
        print('PASS: mock KiCad -> 3-page hierarchy -> PCB 4 pages -> PNG -> README -> validation -> Git commit/push -> no-change run -> re-export')

if __name__ == '__main__':
    main()
