#!/usr/bin/env python3
"""Verify installer systemd units with an isolated fake systemctl and temporary HOME."""
import os
from pathlib import Path
import subprocess
import tempfile

PKG = Path(__file__).resolve().parent.parent

def run(args, **kwargs):
    r = subprocess.run(args, capture_output=True, text=True, **kwargs)
    if r.returncode:
        raise RuntimeError(f'{args}: {r.stdout} {r.stderr}')
    return r.stdout

with tempfile.TemporaryDirectory() as temp:
    root = Path(temp)
    home = root / 'home'
    home.mkdir()
    proj = root / 'My board with spaces'
    proj.mkdir()
    (proj / 'Example.kicad_pro').write_text('{}')
    (proj / 'Example.kicad_sch').write_text('sch')
    (proj / 'Example.kicad_pcb').write_text('pcb')
    run(['git', 'init', '-b', 'main', str(proj)])
    bin_dir = root / 'bin'
    bin_dir.mkdir()
    for name in ('systemctl', 'kicad-cli'):
        program = bin_dir / name
        program.write_text('#!/bin/sh\n[ "$2" = is-active ] && exit 3\nexit 0\n' if name == 'systemctl' else '#!/bin/sh\nexit 0\n')
        program.chmod(0o755)
    env = dict(os.environ, HOME=str(home), PATH=f'{bin_dir}:{os.environ["PATH"]}')
    output = run(['bash', str(PKG / 'install.sh'), str(proj)], env=env)
    units = list((home / '.config/systemd/user').glob('kicad-auto-*.service'))
    assert len(units) == 1, units
    unit = units[0].read_text()
    assert 'Environment="PATH=%h/.local/bin:/usr/local/bin:/usr/bin:/bin"' in unit
    assert 'My board with spaces' in unit
    assert (proj / '.kicad-automation.conf').read_text().startswith('PROJECT_NAME=Example')
    assert len(list((home / '.config/systemd/user').glob('kicad-auto-*.timer'))) == 1
    run(['bash', str(PKG / 'uninstall.sh'), str(proj)], env=env)
    assert not units[0].exists()
    assert not list((home / '.config/systemd/user').glob('kicad-auto-*.timer'))
    assert (proj / 'scripts/auto-git.sh').exists()
    print('PASS: installer selects root, quotes spaces in systemd, sets PATH, installs project units, uninstalls without deleting project files')
