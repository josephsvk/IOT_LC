#!/usr/bin/env bash
# Initialize Git tracking and recommended KiCad ignores for a new KiCad folder.
# Usage: ./bootstrap.sh /path/to/project [--remote https://github.com/USER/REPO.git]
set -Eeuo pipefail
[[ $# -ge 1 ]] || { echo 'Usage: ./bootstrap.sh PROJECT_DIR [--remote URL]' >&2; exit 2; }
TARGET="$(realpath -e "$1")"; shift
REMOTE=''
while (($#)); do
  case "$1" in
    --remote) REMOTE="${2:?Missing remote URL}"; shift 2 ;;
    *) echo "Invalid option: $1" >&2; exit 2 ;;
  esac
done
[[ -d "$TARGET" ]] || exit 1
if [[ ! -e "$TARGET/.gitignore" ]]; then
cat > "$TARGET/.gitignore" <<'IGNORE'
# KiCad user-specific state and local autosaves
*.kicad_prl
.history/
*-backups/
_restore_backup_*/
_autosave-*
*.lck
*.lck~
*.tmp
*.bak
*~

# Generated fabrication files (exported PDF/PNG docs remain tracked)
*.gbr
*.gbrjob
*.drl
production/
*.kicad_pcb.zip

# OS, IDE, Python
.DS_Store
Thumbs.db
__pycache__/
*.pyc
.venv/

# Secrets - extend according to project
.env
.env.*
*.pem
*.key
IGNORE
  echo 'Created .gitignore'
else
  echo 'Existing .gitignore preserved. Review exclusions before auto-git.'
fi
if ! git -C "$TARGET" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git -C "$TARGET" init -b main
fi
if [[ -n "$REMOTE" ]]; then
  if git -C "$TARGET" remote get-url origin >/dev/null 2>&1; then
    echo 'Existing origin preserved. Inspect with git remote -v.'
  else
    git -C "$TARGET" remote add origin "$REMOTE"
  fi
fi
cat <<MSG
Git setup ready in $TARGET
Review staged files before first commit:
  cd "$TARGET"
  git status --short
  git add -A
  git diff --cached --stat
  git commit -m 'Initial KiCad project'
  git push -u origin main  # if origin exists and credentials are configured
Then run install.sh from the automation package.
MSG
