#!/usr/bin/env bash
# Remove the project's systemd timer/service; preserve KiCad sources, docs, scripts and Git history.
set -Eeuo pipefail
[[ $# == 1 ]] || { echo 'Usage: ./uninstall.sh /absolute/or/relative/project/path' >&2; exit 2; }
TARGET="$(realpath -e "$1")"
HASH="$(printf '%s' "$TARGET" | sha256sum | cut -c1-12)"
UNIT="kicad-auto-${HASH}"
DIR="$HOME/.config/systemd/user"
systemctl --user disable --now "$UNIT.timer" 2>/dev/null || true
rm -f "$DIR/$UNIT.timer" "$DIR/$UNIT.service"
systemctl --user daemon-reload
systemctl --user reset-failed "$UNIT.service" 2>/dev/null || true
printf 'Removed %s systemd units. Project files and Git history unchanged.\n' "$UNIT"
